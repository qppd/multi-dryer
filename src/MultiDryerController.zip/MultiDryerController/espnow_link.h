// espnow_link.h
// Multi Dryer Controller — ESP-Now link to the HMI board (ESP32-S3 + touch).
//
// Ported from the HMIDisplay reference (references/HMIDisplay/serial_protocol.cpp),
// but from the controller side: we SEND EspNowStatusPacket (SHT31 + load cell
// data) and RECEIVE EspNowCmdPacket (control commands from the HMI).
//
// Wiring: none between boards — wireless, same channel as the HMI (channel 1).
//
// MAC setup:
//   1. Boot the controller, read "[ESP-NOW] Controller MAC: XX:XX:XX:XX:XX:XX"
//   2. Paste that MAC into CONTROLLER_PEER_MAC in the HMI's serial_protocol.cpp
//   3. Boot the HMI, read its "[HMI] HMI MAC" print
//   4. Paste that MAC into HMI_PEER_MAC below, re-flash the controller

#ifndef ESPNOW_LINK_H
#define ESPNOW_LINK_H

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_mac.h>
#include "espnow_protocol.h"
#include "PINS_CONFIG.h"
#include "SHT31_CONFIG.h"
#include "LOADCELL_CONFIG.h"
#include "PID_CONFIG.h"
#include "DRYER_STATE.h"

// ── HMI peer MAC — UPDATE with the MAC printed by the HMI on boot ─────────────
static uint8_t HMI_PEER_MAC[6] = { 0x28, 0x84, 0x85, 0x55, 0xC0, 0xC8 };

// ── Link state ────────────────────────────────────────────────────────────────
// hmiReachable is written from the ESP-NOW send callback (Wi-Fi task context)
// and read from loop() — hence volatile.
static volatile bool hmiReachable   = false;   // last ESP-NOW send was ACKed by the HMI
static unsigned long lastStatusSent = 0;

// Real SSR output state, maintained by operateSSR() (defined in the .ino).
// Bits match FLAG_HEATER / FLAG_FAN / FLAG_EXHAUST.
extern uint8_t ssrStateFlags;

#define STATUS_SEND_INTERVAL_MS  1000   // status packet cadence (1 Hz)

// ── Command queue (ESP-Now callback → loop context) ───────────────────────────
// The ESP-Now receive callback runs in the Wi-Fi task context — never call
// blocking code (HX711 reads, I2C, prints) from there. Commands are queued in
// a small ring buffer (single producer = WiFi task, single consumer = loop)
// and drained one per loop in espnowUpdate(). A queue (not a single slot)
// guarantees rapid-fire bursts from the HMI — e.g. SET_TEMPERATURE →
// SET_WATER_LOSS → START_DRYING — are never silently dropped, even if they
// arrive while the loop is busy (HX711 tare/calibration, SHT31 read).
#define CMD_QUEUE_SIZE  8

static volatile uint8_t cmdQueueTypes[CMD_QUEUE_SIZE];
static volatile float   cmdQueueValues[CMD_QUEUE_SIZE];
static volatile uint8_t cmdQueueHead = 0;   // producer index (WiFi task)
static volatile uint8_t cmdQueueTail = 0;   // consumer index (loop)

static bool cmdEnqueue(uint8_t type, float value) {
    uint8_t next = (uint8_t)((cmdQueueHead + 1) % CMD_QUEUE_SIZE);
    if (next == cmdQueueTail) return false;   // full — drop the newest
    cmdQueueTypes[cmdQueueHead] = type;
    cmdQueueValues[cmdQueueHead] = value;
    cmdQueueHead = next;
    return true;
}

static bool cmdDequeue(uint8_t* type, float* value) {
    if (cmdQueueHead == cmdQueueTail) return false;
    *type  = cmdQueueTypes[cmdQueueTail];
    *value = cmdQueueValues[cmdQueueTail];
    cmdQueueTail = (uint8_t)((cmdQueueTail + 1) % CMD_QUEUE_SIZE);
    return true;
}

static void handleCmd(uint8_t cmdType, float value);

// ── Receive callback (Wi-Fi task context — keep it short) ─────────────────────
// ESP32 Arduino core 3.x / IDF 5.x passes an esp_now_recv_info_t*, which holds
// the source MAC in info->src_addr. We only talk to one known peer, so it is unused.
static void onEspNowReceive(const esp_now_recv_info_t* info, const uint8_t* data, int len) {
    (void)info;
    if (len < (int)sizeof(EspNowCmdPacket)) return;
    const EspNowCmdPacket* pkt = (const EspNowCmdPacket*)data;
    if (!espnowCmdValid(pkt)) {
        Serial.println("[ESP-NOW] Bad command packet (type/checksum)");
        return;
    }
    cmdEnqueue(pkt->cmdType, pkt->value);
}

// ── Send callback (Wi-Fi task context — keep it short) ────────────────────────
static void onEspNowSent(const uint8_t* mac, esp_now_send_status_t status) {
    hmiReachable = (status == ESP_NOW_SEND_SUCCESS);
}

// ── Build + send one status packet with current sensor data ───────────────────
static void sendStatusNow() {
    EspNowStatusPacket pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.packetType  = ESPNOW_PKT_STATUS;
    pkt.state       = getDryerState();                   // DSTATE_* from the state machine

    // Flags reflect the REAL SSR state (PID-driven or manual override) so the
    // HMI dashboard always shows what is actually energized
    uint8_t flags = sht31OK ? FLAG_SHT31 : 0;
    if (pid.GetMode() == AUTOMATIC) flags |= FLAG_PID;
    flags |= (ssrStateFlags & (FLAG_HEATER | FLAG_FAN | FLAG_EXHAUST));
    pkt.flags           = flags;
    pkt.temperature     = getTemperature();              // °C
    pkt.humidity        = getHumidity();                 // %
    pkt.weight          = getWeightKg();                 // kg (1 Hz cache from state machine)
    pkt.waterLoss       = getWaterLoss();                // %
    pkt.setpoint        = (float)TEMPERATURE_SETPOINT;   // target °C
    pkt.waterLossTarget = getWaterLossTarget();          // %
    pkt.pidOutput       = (float)PID_OUTPUT;
    pkt.runtimeSeconds  = (uint16_t)min((uint32_t)65535, getRuntimeSeconds()); // uint16 field (wraps ~18 h)
    pkt.estimatedEDT    = getEstimatedEDT();             // seconds, 0 = unknown
    pkt.checksum        = espnowStatusChecksum(&pkt);
    esp_now_send(HMI_PEER_MAC, (const uint8_t*)&pkt, sizeof(pkt));
}

// ── MAC helpers ───────────────────────────────────────────────────────────────
static bool macIsZero(const uint8_t mac[6]) {
    static const uint8_t zero[6] = { 0, 0, 0, 0, 0, 0 };
    return memcmp(mac, zero, 6) == 0;
}

// Read this board's STA MAC. WiFi.macAddress() on core 3.x reads the *base* MAC
// through esp_base_mac_addr_get() and can come back as 00:00:00:00:00:00 if the
// Wi-Fi driver is not ready yet (or the eFuse read fails). Ask the running Wi-Fi
// driver first, then fall back to the factory MAC in eFuse.
static bool readStaMac(uint8_t mac[6]) {
    memset(mac, 0, 6);
    if (esp_wifi_get_mac(WIFI_IF_STA, mac) == ESP_OK && !macIsZero(mac)) {
        return true;
    }
    memset(mac, 0, 6);
    if (esp_read_mac(mac, ESP_MAC_WIFI_STA) == ESP_OK && !macIsZero(mac)) {
        return true;
    }
    return false;
}

// ── Init (call once in setup()) ───────────────────────────────────────────────
void initEspNow() {
    // Wi-Fi must be in STA mode (no connection) for ESP-Now
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();

    if (esp_now_init() != ESP_OK) {
        Serial.println("[ESP-NOW] Init FAILED");
        return;
    }

    // Print own MAC so user can copy it into the HMI's CONTROLLER_PEER_MAC.
    // Done AFTER esp_now_init() so the Wi-Fi driver is up and the MAC is valid.
    uint8_t ownMac[6];
    if (readStaMac(ownMac)) {
        Serial.printf("[ESP-NOW] Controller MAC (copy to HMI CONTROLLER_PEER_MAC): "
                      "%02X:%02X:%02X:%02X:%02X:%02X\n",
                      ownMac[0], ownMac[1], ownMac[2], ownMac[3], ownMac[4], ownMac[5]);
    } else {
        Serial.println("[ESP-NOW] MAC read FAILED — cannot pair boards");
    }

    esp_now_register_recv_cb(onEspNowReceive);
    esp_now_register_send_cb(onEspNowSent);

    if (macIsZero(HMI_PEER_MAC)) {
        // Receive still works without a peer entry on ESP32, so the HMI can
        // still reach us. But we have nowhere to send status packets.
        Serial.println("[ESP-NOW] HMI_PEER_MAC is NOT set (00:00:00:00:00:00)");
        Serial.println("[ESP-NOW] → put the HMI MAC in espnow_link.h and re-flash this board");
        return;
    }

    esp_now_peer_info_t peerInfo = {};
    memcpy(peerInfo.peer_addr, HMI_PEER_MAC, 6);
    peerInfo.channel = ESPNOW_WIFI_CHANNEL;
    peerInfo.encrypt = false;
    if (esp_now_add_peer(&peerInfo) != ESP_OK) {
        Serial.println("[ESP-NOW] Add peer FAILED — is HMI_PEER_MAC valid?");
    }

    Serial.printf("[ESP-NOW] Link ready. HMI peer: %02X:%02X:%02X:%02X:%02X:%02X\n",
                  HMI_PEER_MAC[0], HMI_PEER_MAC[1], HMI_PEER_MAC[2],
                  HMI_PEER_MAC[3], HMI_PEER_MAC[4], HMI_PEER_MAC[5]);
}

// ── Process queued commands + send periodic status (call every loop()) ────────
void espnowUpdate() {
    // 1) Process one queued HMI command per loop iteration (none are dropped;
    //    the queue holds the rest until the loop is free)
    uint8_t cmdType;
    float   cmdValue;
    if (cmdDequeue(&cmdType, &cmdValue)) {
        handleCmd(cmdType, cmdValue);
    }

    // 2) Periodic status broadcast (1 Hz)
    unsigned long now = millis();
    if (now - lastStatusSent >= STATUS_SEND_INTERVAL_MS) {
        lastStatusSent = now;
        sendStatusNow();
    }
}

// ── Command dispatch ──────────────────────────────────────────────────────────
static void handleCmd(uint8_t cmdType, float value) {
    switch (cmdType) {
        case CMD_STATUS_REQUEST:
            sendStatusNow();              // HMI wants an immediate reading
            break;
        case CMD_SENSOR_TEST:
            sendStatusNow();
            break;

        // Load cell calibration — only allowed while IDLE. The HMI sends a TARE
        // at every boot (boot screen → dashboard); if a session was restored,
        // taring would destroy the saved zero reference and corrupt water loss.
        case CMD_TARE_SCALE:
            if (getDryerState() == DSTATE_IDLE) {
                tareLoadCell();
            } else {
                Serial.println(F("[DRYER] TARE ignored — session active (would break water-loss reference)"));
            }
            break;
        case CMD_CALIBRATE_SCALE:
            if (getDryerState() == DSTATE_IDLE) {
                calibrateLoadCell(value);
            } else {
                Serial.println(F("[DRYER] CALIBRATE ignored — session active"));
            }
            break;

        // Drying session control (state machine)
        case CMD_START_DRYING:
        case CMD_PID_START:               // alias (FishDryer baseline)
            startDrying();
            break;
        case CMD_STOP_DRYING:
        case CMD_PID_STOP:
            stopDrying();
            break;
        case CMD_PAUSE_DRYING:
            pauseDrying();
            break;
        case CMD_RESUME_DRYING:
            resumeDrying();
            break;

        // Process parameters — persist after each change so a reboot keeps the
        // HMI's configured values even when no session is active.
        case CMD_SET_TEMPERATURE:
            setPIDSetpoint(value);
            persistDryerConfig();
            break;
        case CMD_SET_WATER_LOSS:
            setWaterLossTarget(value);
            persistDryerConfig();
            break;

        // Manual overrides (HMI manual-operation screen) — any manual command
        // ends the current drying session first, so PID/state machine and
        // manual control can never fight.
        case CMD_HEATER_ON:
            stopDrying();
            operateSSR(1, true);          // PTC heater ON
            operateSSR(3, true);          // inlet fan ON (airflow with heat!)
            break;
        case CMD_HEATER_OFF:
            stopDrying();
            break;
        case CMD_FAN_ON:
            stopDrying();
            operateSSR(3, true);          // inlet fan ON
            break;
        case CMD_FAN_OFF:
            stopDrying();
            break;
        case CMD_EXHAUST_ON:
            stopDrying();
            operateSSR(4, true);          // exhaust fan ON
            break;
        case CMD_EXHAUST_OFF:
            stopDrying();
            break;

        default:
            Serial.printf("[ESP-NOW] CMD 0x%02X received (unknown)\n", cmdType);
            break;
    }
}

#endif // ESPNOW_LINK_H
